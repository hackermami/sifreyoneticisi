package com.aistudio.blindsight.webnetik.service

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout

/**
 * Webnetik BlindSight V2.0 - Real-Time Coordinate-Based Invisible Shield Accessibility Service
 * Manages an ultra-fast, zero-delay regional overlay system that masks specific segments of the screen
 * (Top 33%, Bottom 33%, Left 33%, Right 33% or Full) while leaving other portions interactive.
 */
class BlindSightService : AccessibilityService() {

    private var windowManager: WindowManager? = null
    private var overlayView: FrameLayout? = null
    private var isOverlayShown = false

    private var fullMask: View? = null
    private var topMask: View? = null
    private var bottomMask: View? = null
    private var leftMask: View? = null
    private var rightMask: View? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // System accessibility events are bypassed
    }

    override fun onInterrupt() {
        // Handle interruption
    }

    override fun onDestroy() {
        super.onDestroy()
        hideBlackOverlay()
        instance = null
    }

    /**
     * Updates the active screen shield region instantly with zero-delay (0ms latency).
     * Automatically toggles specific masks based on state.
     */
    fun updateOverlayRegion(region: String) {
        if (region == "NONE") {
            hideBlackOverlay()
            return
        }

        // Ensure parent overlay view is attached
        showBlackOverlay()

        // Apply instant state-driven visibility changes on the UI thread
        fullMask?.visibility = if (region == "FULL") View.VISIBLE else View.GONE
        topMask?.visibility = if (region == "TOP") View.VISIBLE else View.GONE
        bottomMask?.visibility = if (region == "BOTTOM") View.VISIBLE else View.GONE
        leftMask?.visibility = if (region == "LEFT") View.VISIBLE else View.GONE
        rightMask?.visibility = if (region == "RIGHT") View.VISIBLE else View.GONE
    }

    /**
     * Inflates the overlay view container and attaches it to the WindowManager.
     * Uses TYPE_ACCESSIBILITY_OVERLAY with FLAG_NOT_TOUCHABLE to allow user input pass-through.
     */
    fun showBlackOverlay() {
        if (isOverlayShown) return
        val wm = windowManager ?: return

        val parentLayout = FrameLayout(this)

        // 1. Full Screen Mask
        fullMask = View(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            visibility = View.GONE
        }
        parentLayout.addView(fullMask, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        // Get actual display metrics for precision calculations
        val displayMetrics = resources.displayMetrics
        val height33 = (displayMetrics.heightPixels * 0.33f).toInt()
        val width33 = (displayMetrics.widthPixels * 0.33f).toInt()

        // 2. Top 33% Mask
        topMask = View(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            visibility = View.GONE
        }
        parentLayout.addView(topMask, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            height33,
            Gravity.TOP
        ))

        // 3. Bottom 33% Mask
        bottomMask = View(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            visibility = View.GONE
        }
        parentLayout.addView(bottomMask, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            height33,
            Gravity.BOTTOM
        ))

        // 4. Left 33% Mask
        leftMask = View(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            visibility = View.GONE
        }
        parentLayout.addView(leftMask, FrameLayout.LayoutParams(
            width33,
            FrameLayout.LayoutParams.MATCH_PARENT,
            Gravity.LEFT
        ))

        // 5. Right 33% Mask
        rightMask = View(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            visibility = View.GONE
        }
        parentLayout.addView(rightMask, FrameLayout.LayoutParams(
            width33,
            FrameLayout.LayoutParams.MATCH_PARENT,
            Gravity.RIGHT
        ))

        val params = WindowManager.LayoutParams().apply {
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
            type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            
            // Critical V2.0 Flag: FLAG_NOT_TOUCHABLE allows taps to seamlessly pass through to apps underneath
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR
            format = PixelFormat.TRANSLUCENT
        }

        try {
            wm.addView(parentLayout, params)
            overlayView = parentLayout
            isOverlayShown = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Tears down the overlay view from the WindowManager instantly.
     */
    fun hideBlackOverlay() {
        if (!isOverlayShown) return
        val wm = windowManager ?: return
        try {
            overlayView?.let { wm.removeViewImmediate(it) }
            overlayView = null
            fullMask = null
            topMask = null
            bottomMask = null
            leftMask = null
            rightMask = null
            isOverlayShown = false
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    companion object {
        @Volatile
        var instance: BlindSightService? = null
            private set

        /**
         * Checks if the Accessibility Service is currently active and running.
         */
        fun isRunning(): Boolean = instance != null
    }
}
