package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import com.aistudio.blindsight.webnetik.service.BlindSightService
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Webnetik BlindSight V2.0 - High-Performance local Edge-AI Front-Facing Camera Security Service
 * Utilizes local ML Kit Face Tracking and Eye landmarks to identify multi-face situations,
 * performing Anti-Mirror/Anti-Reflection matching, Liveness/Photo Spoofing detection,
 * and high-fidelity Eye Gaze/Pitch mapping for targeted coordinate screen masking.
 */
class BlindSightForegroundService : Service(), LifecycleOwner {

    private lateinit var cameraExecutor: ExecutorService
    private lateinit var faceDetector: FaceDetector
    private var lastSecondFaceDetectedTime = 0L

    // Blink states
    private var lastBlinkStateOwner = true
    private var lastBlinkStateThreat = true

    // Telemetry and history for Liveness / Anti-Spoofing algorithm
    private val threatHistoryYaw = mutableListOf<Float>()
    private val threatHistoryPitch = mutableListOf<Float>()
    private val threatHistoryOpenProb = mutableListOf<Float>()
    private val maxHistorySize = 25

    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry

    companion object {
        private const val TAG = "BlindSightService"
        private const val CHANNEL_ID = "blindsight_service_channel"
        private const val NOTIFICATION_ID = 4829
        private const val DEBOUNCE_DELAY_MS = 300L // Reduced for ultra-fast reaction

        @Volatile
        var isRunning = false
            private set
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Service onCreate")
        
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        cameraExecutor = Executors.newSingleThreadExecutor()

        // Configure Face Detector for High Fidelity Landmarks, Tracking and Classifications
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .enableTracking()
            .build()
        faceDetector = FaceDetection.getClient(options)

        isRunning = true
        BlindSightState.isServiceRunning.value = true

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        startCameraAndAnalysis()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Webnetik BlindSight Protection"
            val descriptionText = "Yapay zeka omuz sörfü koruma arka plan hizmeti."
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Webnetik BlindSight V2.0")
            .setContentText("Yerel siber yapay zeka ekran savunması aktif.")
            .setSmallIcon(R.drawable.ic_slashed_eye)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun startCameraAndAnalysis() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val imageAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                analyzeImage(imageProxy)
            }

            val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this,
                    cameraSelector,
                    imageAnalysis
                )
                Log.d(TAG, "Camera bound successfully to foreground service lifecycle.")
            } catch (exc: Exception) {
                Log.e(TAG, "Camera binding failed", exc)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @OptIn(ExperimentalGetImage::class)
    private fun analyzeImage(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage != null) {
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            faceDetector.process(image)
                .addOnSuccessListener { faces ->
                    processFaces(faces)
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "Face detection error", e)
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        } else {
            imageProxy.close()
        }
    }

    private fun processFaces(faces: List<Face>) {
        val rawCount = faces.size
        
        // 1. Filter out duplicate split frames or mirror reflections
        val uniqueFaces = filterMirrorReflections(faces)
        val faceCount = uniqueFaces.size
        BlindSightState.faceCount.value = faceCount

        if (faceCount < 2) {
            // Standard state: Zero or only one face (the device owner)
            val timeSinceLastThreat = System.currentTimeMillis() - lastSecondFaceDetectedTime
            if (timeSinceLastThreat >= DEBOUNCE_DELAY_MS) {
                BlindSightState.threatDetected.value = false
                BlindSightState.threatRegion.value = "NONE"
                BlindSightState.threatLiveness.value = "LIVE"
                BlindSightState.threatGazeDetails.value = "Göz Odaklaması Aranıyor..."
                
                // Clear threat history buffer
                threatHistoryYaw.clear()
                threatHistoryPitch.clear()
                threatHistoryOpenProb.clear()

                // Recover and remove overlay instantly
                BlindSightService.instance?.let { service ->
                    ContextCompat.getMainExecutor(this).execute {
                        service.updateOverlayRegion("NONE")
                    }
                }
            }

            // Also analyze Owner's eye blink telemetry for the dashboard
            uniqueFaces.firstOrNull()?.let { owner ->
                analyzeOwnerBlinks(owner)
            }
            return
        }

        // 2. Multi-face situation detected! Sort by bounding box area to identify the primary owner face
        val sortedFaces = uniqueFaces.sortedByDescending { it.boundingBox.width() * it.boundingBox.height() }
        val ownerFace = sortedFaces.first()
        val threatFace = sortedFaces[1] // The second face closest/largest

        analyzeOwnerBlinks(ownerFace)

        // 3. Perform anti-spoofing liveness verification on the second face (threat face)
        val liveness = analyzeThreatLiveness(threatFace)
        BlindSightState.threatLiveness.value = liveness

        // 4. Verify if the intruder face is looking directly towards the screen (Focus Detection)
        val isFocusing = checkIfThreatIsFocusing(threatFace)

        if (isFocusing) {
            lastSecondFaceDetectedTime = System.currentTimeMillis()
            BlindSightState.threatDetected.value = true

            // 5. Determine looking direction for targeted coordinate-based masking (Top, Bottom, Left, Right or Full)
            val targetedRegion = mapGazeToRegion(threatFace)
            BlindSightState.threatRegion.value = targetedRegion
            BlindSightState.threatGazeDetails.value = "Tehdit Odağı: %s (%s)".format(targetedRegion, liveness)

            // Instantly trigger regional blackout with 0ms transition latency
            BlindSightService.instance?.let { service ->
                ContextCompat.getMainExecutor(this).execute {
                    service.updateOverlayRegion(targetedRegion)
                }
            }
        } else {
            // Threat face is looking away; check if debounce period has elapsed to hide overlay
            val timeSinceLastThreat = System.currentTimeMillis() - lastSecondFaceDetectedTime
            if (timeSinceLastThreat >= DEBOUNCE_DELAY_MS) {
                BlindSightState.threatDetected.value = false
                BlindSightState.threatRegion.value = "NONE"
                BlindSightState.threatGazeDetails.value = "Snoop-Bulanık Bakış (Koruma Hazır)"

                BlindSightService.instance?.let { service ->
                    ContextCompat.getMainExecutor(this).execute {
                        service.updateOverlayRegion("NONE")
                    }
                }
            }
        }
    }

    /**
     * Filters out mirrored camera artifacts or reflection noise.
     * If two faces share matching rotation matrices and size proportions, they are filtered out.
     */
    private fun filterMirrorReflections(faces: List<Face>): List<Face> {
        if (faces.size < 2) return faces
        val result = mutableListOf<Face>()
        val skipSet = mutableSetOf<Int>()

        for (i in faces.indices) {
            if (i in skipSet) continue
            val f1 = faces[i]
            result.add(f1)

            for (j in i + 1 until faces.size) {
                val f2 = faces[j]
                val angleDiffX = Math.abs(f1.headEulerAngleX - f2.headEulerAngleX)
                val angleDiffY = Math.abs(f1.headEulerAngleY - f2.headEulerAngleY)
                val angleDiffZ = Math.abs(f1.headEulerAngleZ - f2.headEulerAngleZ)
                
                val area1 = f1.boundingBox.width() * f1.boundingBox.height()
                val area2 = f2.boundingBox.width() * f2.boundingBox.height()
                val areaRatio = if (area1 > area2) area2.toFloat() / area1 else area1.toFloat() / area2

                // If angles and size ratio are too correlated, it is classified as a reflection
                if (angleDiffX < 2.5f && angleDiffY < 2.5f && angleDiffZ < 2.5f && areaRatio > 0.88f) {
                    skipSet.add(j)
                    Log.d(TAG, "Mirror/Reflection artifact filtered out between face indices: $i and $j")
                }
            }
        }
        return result
    }

    /**
     * Calculates Owner blink telemetry dynamically to display in the system status monitor.
     */
    private fun analyzeOwnerBlinks(owner: Face) {
        val leftProb = owner.leftEyeOpenProbability
        val rightProb = owner.rightEyeOpenProbability
        if (leftProb != null && rightProb != null) {
            val avgOpen = (leftProb + rightProb) / 2.0f
            if (avgOpen < 0.15f && lastBlinkStateOwner) {
                lastBlinkStateOwner = false
                BlindSightState.ownerBlinkCount.value += 1
            } else if (avgOpen > 0.80f) {
                lastBlinkStateOwner = true
            }
        }
    }

    /**
     * Computes real-time liveness indicators to differentiate a live intruder from flat phone photo spoofing.
     * Evaluates micro-movements of eyes, pose angles, and blink events over rolling samples.
     */
    private fun analyzeThreatLiveness(threat: Face): String {
        // Blink tracking for threat face
        val leftProb = threat.leftEyeOpenProbability
        val rightProb = threat.rightEyeOpenProbability
        val avgOpen = if (leftProb != null && rightProb != null) (leftProb + rightProb) / 2.0f else 1.0f

        if (leftProb != null && rightProb != null) {
            if (avgOpen < 0.15f && lastBlinkStateThreat) {
                lastBlinkStateThreat = false
                BlindSightState.threatBlinkCount.value += 1
            } else if (avgOpen > 0.80f) {
                lastBlinkStateThreat = true
            }
        }

        // Store history samples
        threatHistoryYaw.add(threat.headEulerAngleY)
        threatHistoryPitch.add(threat.headEulerAngleX)
        threatHistoryOpenProb.add(avgOpen)

        if (threatHistoryYaw.size > maxHistorySize) {
            threatHistoryYaw.removeAt(0)
            threatHistoryPitch.removeAt(0)
            threatHistoryOpenProb.removeAt(0)
        }

        // Only decide after enough frames are analyzed
        if (threatHistoryYaw.size >= 12) {
            val yawRange = threatHistoryYaw.maxOrNull()!! - threatHistoryYaw.minOrNull()!!
            val pitchRange = threatHistoryPitch.maxOrNull()!! - threatHistoryPitch.minOrNull()!!
            val openProbRange = threatHistoryOpenProb.maxOrNull()!! - threatHistoryOpenProb.minOrNull()!!

            // Flat paper or static image has absolute 0 variance in eye-blink probability and head posture
            if (yawRange < 0.08f && pitchRange < 0.08f && openProbRange < 0.002f) {
                return "FOTOĞRAF_TEHDİDİ"
            }
        }
        return "CANLI"
    }

    /**
     * Checks if the threat face's gaze vector is looking directly towards the screen bounds.
     */
    private fun checkIfThreatIsFocusing(threat: Face): Boolean {
        val yaw = Math.abs(threat.headEulerAngleY)
        val pitch = Math.abs(threat.headEulerAngleX)
        
        // A direct screen gaze is oriented within 22 degrees in both axes
        return yaw < 22f && pitch < 22f
    }

    /**
     * Maps the threat face's gaze vector to specific screen segments for invisible coordinate masking.
     */
    private fun mapGazeToRegion(threat: Face): String {
        val yaw = threat.headEulerAngleY
        val pitch = threat.headEulerAngleX

        // 1. Vertical looking angles (Up/Down)
        if (pitch > 10f) {
            return "TOP"
        } else if (pitch < -10f) {
            return "BOTTOM"
        }

        // 2. Horizontal looking angles (Left/Right)
        if (yaw < -10f) {
            return "LEFT"
        } else if (yaw > 10f) {
            return "RIGHT"
        }

        // Default to full coverage if they are scanning widely
        return "FULL"
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Service onDestroy")
        
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)

        isRunning = false
        BlindSightState.isServiceRunning.value = false
        BlindSightState.threatDetected.value = false
        BlindSightState.faceCount.value = 0
        BlindSightState.threatRegion.value = "NONE"

        cameraExecutor.shutdown()
        faceDetector.close()

        BlindSightService.instance?.let { service ->
            ContextCompat.getMainExecutor(this).execute {
                service.updateOverlayRegion("NONE")
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}
