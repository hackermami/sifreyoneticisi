package com.example

import kotlinx.coroutines.flow.MutableStateFlow

object BlindSightState {
    val isServiceRunning = MutableStateFlow(false)
    val threatDetected = MutableStateFlow(false)
    val faceCount = MutableStateFlow(0)
    
    // V2.0 Advanced AI Telemetry Flows
    val threatRegion = MutableStateFlow("NONE") // "NONE", "TOP", "BOTTOM", "LEFT", "RIGHT", "FULL"
    val threatLiveness = MutableStateFlow("LIVE") // "LIVE", "PHOTO_SPOOF", "PENDING"
    val threatGazeDetails = MutableStateFlow("Göz Odaklaması Aranıyor...")
    val ownerBlinkCount = MutableStateFlow(0)
    val threatBlinkCount = MutableStateFlow(0)
}
