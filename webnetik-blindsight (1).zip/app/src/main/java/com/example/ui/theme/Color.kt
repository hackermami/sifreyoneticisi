package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Webnetik Security Corporate Palette
val MidnightBlue = Color(0xFF0A1128)     // Deep Night Blue background
val SlateBlue = Color(0xFF16223F)        // Surface container card blue
val TitaniumWhite = Color(0xFFF8FAFC)    // Clean, crisp text white
val CoolGray = Color(0xFF94A3B8)         // Secondary titanium-silver labels
val ElectricBlue = Color(0xFF2563EB)     // Modern, secure accent blue
val DarkOverlay = Color(0xFF020617)      // Premium dark overlay base
val ShieldRed = Color(0xFFEF4444)        // Alert/threat red accent (contrast detail)
val DarkSteel = Color(0xFF334155)        // Outline strokes
