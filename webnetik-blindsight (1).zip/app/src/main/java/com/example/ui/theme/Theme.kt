package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val WebnetikColorScheme = darkColorScheme(
    primary = ElectricBlue,
    onPrimary = TitaniumWhite,
    secondary = CoolGray,
    onSecondary = MidnightBlue,
    background = MidnightBlue,
    onBackground = TitaniumWhite,
    surface = SlateBlue,
    onSurface = TitaniumWhite,
    outline = DarkSteel,
    error = ShieldRed,
    onError = TitaniumWhite
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = WebnetikColorScheme,
        typography = Typography,
        content = content
    )
}
