package com.example

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout

class BlindSightAccessibilityService : AccessibilityService() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var isOverlayShown = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Accessibility events are not processed as we only use the window overlay capabilities
    }

    override fun onInterrupt() {
        // Handle interruption of service if required
    }

    override fun onDestroy() {
        super.onDestroy()
        hideOverlay()
        instance = null
    }

    /**
     * Draws a full-screen solid black overlay on the screen to prevent shoulder surfing.
     */
    fun showOverlay() {
        if (isOverlayShown) return
        val wm = windowManager ?: return

        overlayView = FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
        }

        val params = WindowManager.LayoutParams().apply {
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
            type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR
            format = PixelFormat.TRANSLUCENT
        }

        try {
            wm.addView(overlayView, params)
            isOverlayShown = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Instantly removes the full-screen black overlay when the threat disappears.
     */
    fun hideOverlay() {
        if (!isOverlayShown) return
        val wm = windowManager ?: return
        try {
            overlayView?.let { wm.removeView(it) }
            overlayView = null
            isOverlayShown = false
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    companion object {
        @Volatile
        var instance: BlindSightAccessibilityService? = null
            private set

        fun isRunning(): Boolean = instance != null
    }
}
