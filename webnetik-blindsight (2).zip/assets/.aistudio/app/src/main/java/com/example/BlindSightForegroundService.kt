package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class BlindSightForegroundService : Service(), LifecycleOwner {

    private lateinit var cameraExecutor: ExecutorService
    private lateinit var faceDetector: FaceDetector
    private var lastSecondFaceDetectedTime = 0L

    // Manually manage a LifecycleRegistry to bind CameraX use cases to our background service
    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry

    companion object {
        private const val TAG = "BlindSightService"
        private const val CHANNEL_ID = "blindsight_service_channel"
        private const val NOTIFICATION_ID = 4829
        private const val DEBOUNCE_DELAY_MS = 500L // Prevent screen flickering

        @Volatile
        var isRunning = false
            private set
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Service onCreate")
        
        // Transition the manual lifecycle to active state so CameraX binds successfully
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        cameraExecutor = Executors.newSingleThreadExecutor()

        // Configure Face Detector for High Performance, Low Latency Local Analysis
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
            .build()
        faceDetector = FaceDetection.getClient(options)

        // Register active service state
        isRunning = true
        BlindSightState.isServiceRunning.value = true

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        startCameraAndAnalysis()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Webnetik BlindSight Protection"
            val descriptionText = "Yapay zeka omuz sörfü koruma arka plan hizmeti."
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Webnetik BlindSight")
            .setContentText("Yerel yapay zeka ekran savunması aktif.")
            .setSmallIcon(R.drawable.ic_slashed_eye)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun startCameraAndAnalysis() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            // Setup image analysis for real-time offline local processing
            val imageAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                analyzeImage(imageProxy)
            }

            val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this,
                    cameraSelector,
                    imageAnalysis
                )
                Log.d(TAG, "Camera bound successfully to foreground service lifecycle.")
            } catch (exc: Exception) {
                Log.e(TAG, "Camera binding failed", exc)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @OptIn(ExperimentalGetImage::class)
    private fun analyzeImage(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage != null) {
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            faceDetector.process(image)
                .addOnSuccessListener { faces ->
                    processFaces(faces)
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "Face detection error", e)
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        } else {
            imageProxy.close()
        }
    }

    private fun processFaces(faces: List<Face>) {
        val totalFaces = faces.size
        BlindSightState.faceCount.value = totalFaces

        if (totalFaces >= 2) {
            // Intruder face detected!
            lastSecondFaceDetectedTime = System.currentTimeMillis()
            BlindSightState.threatDetected.value = true
            
            // Instantly summon the overlay on the UI thread
            BlindSightAccessibilityService.instance?.let { service ->
                ContextCompat.getMainExecutor(this).execute {
                    service.showOverlay()
                }
            }
        } else {
            // Standard user or zero face
            val timeSinceLastThreat = System.currentTimeMillis() - lastSecondFaceDetectedTime
            if (timeSinceLastThreat >= DEBOUNCE_DELAY_MS) {
                BlindSightState.threatDetected.value = false
                
                // Recover and remove overlay immediately on the UI thread
                BlindSightAccessibilityService.instance?.let { service ->
                    ContextCompat.getMainExecutor(this).execute {
                        service.hideOverlay()
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Service onDestroy")
        
        // Gracefully teardown the manual lifecycle
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)

        isRunning = false
        BlindSightState.isServiceRunning.value = false
        BlindSightState.threatDetected.value = false
        BlindSightState.faceCount.value = 0

        // Shutdown camera execution and clean up face detector
        cameraExecutor.shutdown()
        faceDetector.close()

        // Assure overlay is removed when service is stopped
        BlindSightAccessibilityService.instance?.let { service ->
            ContextCompat.getMainExecutor(this).execute {
                service.hideOverlay()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}
