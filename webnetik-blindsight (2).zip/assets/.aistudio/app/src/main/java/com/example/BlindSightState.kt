package com.example

import kotlinx.coroutines.flow.MutableStateFlow

object BlindSightState {
    val isServiceRunning = MutableStateFlow(false)
    val threatDetected = MutableStateFlow(false)
    val faceCount = MutableStateFlow(0)
}
