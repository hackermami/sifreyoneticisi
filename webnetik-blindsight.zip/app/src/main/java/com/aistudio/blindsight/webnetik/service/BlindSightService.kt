package com.aistudio.blindsight.webnetik.service

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout

/**
 * Webnetik BlindSight - High-Level Local AI-Based Screen Defense Accessibility Service
 * This service runs in the background and is responsible for drawing a full-screen, opaque black overlay
 * to instantly obscure the screen when a shoulder-surfing threat is detected by our local AI model.
 */
class BlindSightService : AccessibilityService() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var isOverlayShown = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // System events are ignored as this service solely manages the security overlay
    }

    override fun onInterrupt() {
        // Handle interruption of service if required
    }

    override fun onDestroy() {
        super.onDestroy()
        hideBlackOverlay()
        instance = null
    }

    /**
     * Draws a high-priority full-screen solid black overlay to prevent unauthorized screen viewing.
     * Uses TYPE_ACCESSIBILITY_OVERLAY to cover all windows, system status bars, and keyboard layers.
     */
    fun showBlackOverlay() {
        if (isOverlayShown) return
        val wm = windowManager ?: return

        // Run overlay initialization on the main thread
        overlayView = FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
        }

        val params = WindowManager.LayoutParams().apply {
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
            type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR
            format = PixelFormat.TRANSLUCENT
        }

        try {
            wm.addView(overlayView, params)
            isOverlayShown = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Instantly removes the full-screen black overlay once the threat disappears,
     * restoring the screen to its previous state with sub-millisecond recovery latency.
     */
    fun hideBlackOverlay() {
        if (!isOverlayShown) return
        val wm = windowManager ?: return
        try {
            overlayView?.let { wm.removeViewImmediate(it) }
            overlayView = null
            isOverlayShown = false
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    companion object {
        @Volatile
        var instance: BlindSightService? = null
            private set

        /**
         * Checks if the Accessibility Service is currently active and running.
         */
        fun isRunning(): Boolean = instance != null
    }
}
