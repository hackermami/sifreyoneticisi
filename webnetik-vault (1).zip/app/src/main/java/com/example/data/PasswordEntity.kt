package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "passwords")
data class PasswordEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val platformName: String,
    val username: String = "",
    val password: String,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
