package com.example.data

import kotlinx.coroutines.flow.Flow

class PasswordRepository(private val passwordDao: PasswordDao) {
    val allPasswords: Flow<List<PasswordEntity>> = passwordDao.getAllPasswords()

    fun searchPasswords(query: String): Flow<List<PasswordEntity>> {
        return passwordDao.searchPasswords("%$query%")
    }

    suspend fun insert(password: PasswordEntity) {
        passwordDao.insertPassword(password)
    }

    suspend fun update(password: PasswordEntity) {
        passwordDao.updatePassword(password)
    }

    suspend fun delete(password: PasswordEntity) {
        passwordDao.deletePassword(password)
    }

    suspend fun deleteById(id: Int) {
        passwordDao.deletePasswordById(id)
    }
}
