package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.PasswordEntity
import com.example.data.PasswordRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class Screen {
    object Splash : Screen()
    object SetupLogin : Screen()
    object Login : Screen()
    object Dashboard : Screen()
    object AddPlatform : Screen()
    object Settings : Screen()
}

class PasswordViewModel(
    application: Application,
    private val repository: PasswordRepository
) : AndroidViewModel(application) {

    private val sharedPrefs = application.getSharedPreferences("webnetik_prefs", Context.MODE_PRIVATE)

    private val _currentScreen = MutableStateFlow<Screen>(Screen.Splash)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Splash State
    private val _isSplashLoading = MutableStateFlow(true)
    val isSplashLoading: StateFlow<Boolean> = _isSplashLoading.asStateFlow()

    // Passwords list reactively filtered by search query
    val passwords: StateFlow<List<PasswordEntity>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) {
                repository.allPasswords
            } else {
                repository.searchPasswords(query)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Platform logo lookup
    fun getLogoUrl(platformName: String): String {
        val trimmed = platformName.trim().lowercase()
        if (trimmed.isEmpty()) return ""
        
        // Ensure we format standard domains properly
        val domain = when (trimmed) {
            "instagram" -> "instagram.com"
            "facebook" -> "facebook.com"
            "google" -> "google.com"
            "twitter" -> "twitter.com"
            "x" -> "x.com"
            "netflix" -> "netflix.com"
            "spotify" -> "spotify.com"
            "github" -> "github.com"
            "linkedin" -> "linkedin.com"
            "microsoft" -> "microsoft.com"
            "apple" -> "apple.com"
            "youtube" -> "youtube.com"
            "amazon" -> "amazon.com"
            "adobe" -> "adobe.com"
            "zoom" -> "zoom.us"
            "discord" -> "discord.com"
            "twitch" -> "twitch.tv"
            "reddit" -> "reddit.com"
            "pinterest" -> "pinterest.com"
            "snapchat" -> "snapchat.com"
            "tiktok" -> "tiktok.com"
            "telegram" -> "telegram.org"
            "whatsapp" -> "whatsapp.com"
            "steam" -> "steampowered.com"
            "paypal" -> "paypal.com"
            "ebay" -> "ebay.com"
            else -> {
                // If contains domain ending, use as is, otherwise guess domain
                if (trimmed.contains(".")) trimmed else "$trimmed.com"
            }
        }
        return "https://logo.clearbit.com/$domain"
    }

    fun isMasterPasswordSet(): Boolean {
        return sharedPrefs.contains("master_password")
    }

    fun saveMasterPassword(passwordText: String) {
        sharedPrefs.edit().putString("master_password", passwordText).apply()
    }

    fun verifyMasterPassword(passwordText: String): Boolean {
        val saved = sharedPrefs.getString("master_password", "") ?: ""
        return saved == passwordText
    }

    init {
        // Run splash screen simulation
        viewModelScope.launch {
            delay(1500) // Fast and elegant splash screen transition
            _isSplashLoading.value = false
            if (isMasterPasswordSet()) {
                _currentScreen.value = Screen.Login
            } else {
                _currentScreen.value = Screen.SetupLogin
            }
        }
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun addPassword(platformName: String, username: String, passwordText: String, notes: String = "") {
        viewModelScope.launch {
            repository.insert(
                PasswordEntity(
                    platformName = platformName.trim(),
                    username = username.trim(),
                    password = passwordText,
                    notes = notes.trim()
                )
            )
        }
    }

    fun deletePassword(passwordEntity: PasswordEntity) {
        viewModelScope.launch {
            repository.delete(passwordEntity)
        }
    }

    fun updatePassword(passwordEntity: PasswordEntity) {
        viewModelScope.launch {
            repository.update(passwordEntity)
        }
    }

    // Password generator helper
    fun generateSecurePassword(length: Int = 16, includeNumbers: Boolean = true, includeSymbols: Boolean = true): String {
        val uppercaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        val lowercaseLetters = "abcdefghijklmnopqrstuvwxyz"
        val numbers = "0123456789"
        val symbols = "!@#$%^&*()-_=+[]{}|;:,.<>?"
        
        var allowedChars = uppercaseLetters + lowercaseLetters
        if (includeNumbers) allowedChars += numbers
        if (includeSymbols) allowedChars += symbols

        val secureRandom = java.security.SecureRandom()
        val password = StringBuilder()
        
        // Guarantee at least one of each selected type
        password.append(uppercaseLetters[secureRandom.nextInt(uppercaseLetters.length)])
        password.append(lowercaseLetters[secureRandom.nextInt(lowercaseLetters.length)])
        if (includeNumbers) {
            password.append(numbers[secureRandom.nextInt(numbers.length)])
        }
        if (includeSymbols) {
            password.append(symbols[secureRandom.nextInt(symbols.length)])
        }
        
        val remainingLength = length - password.length
        for (i in 0 until remainingLength) {
            val randomIndex = secureRandom.nextInt(allowedChars.length)
            password.append(allowedChars[randomIndex])
        }
        
        // Shuffle characters
        val list = password.toString().toList().shuffled()
        return list.joinToString("")
    }
}

class PasswordViewModelFactory(
    private val application: Application,
    private val repository: PasswordRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PasswordViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return PasswordViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
