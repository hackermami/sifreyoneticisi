package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.PasswordEntity
import com.example.ui.PasswordViewModel
import com.example.ui.Screen
import com.example.ui.theme.WebnetikBlack
import com.example.ui.theme.WebnetikBorder
import com.example.ui.theme.WebnetikCardGrey
import com.example.ui.theme.WebnetikGrayText
import com.example.ui.theme.WebnetikRed
import com.example.ui.theme.WebnetikRedLight
import com.example.ui.theme.WebnetikSurface
import com.example.ui.theme.WebnetikWhite

@Composable
fun WebnetikLogo(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .width(130.dp)
            .height(90.dp)
            .clip(RoundedCornerShape(45.dp)) // Oval / capsule design
            .background(WebnetikRed)
            .border(2.dp, WebnetikWhite.copy(alpha = 0.3f), RoundedCornerShape(45.dp)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Key,
            contentDescription = "Webnetik Key",
            tint = WebnetikWhite,
            modifier = Modifier.size(44.dp)
        )
    }
}

@Composable
fun MainAppContent(viewModel: PasswordViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(WebnetikBlack)
    ) {
        when (currentScreen) {
            is Screen.Splash -> {
                SplashScreen()
            }
            is Screen.SetupLogin -> {
                SetupLoginScreen(viewModel = viewModel)
            }
            is Screen.Login -> {
                LoginScreen(viewModel = viewModel)
            }
            is Screen.Dashboard -> {
                DashboardScreen(viewModel = viewModel)
            }
            is Screen.AddPlatform -> {
                AddPlatformScreen(viewModel = viewModel)
            }
            is Screen.Settings -> {
                SettingsScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun SplashScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F7)), // Professional, clean light gray background
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            WebnetikLogo()
            Spacer(modifier = Modifier.height(32.dp))
            CircularProgressIndicator(
                color = Color.Black, // Modern spinning black loader
                strokeWidth = 3.5.dp,
                modifier = Modifier
                    .size(32.dp)
                    .testTag("splash_loading")
            )
        }
    }
}

@Composable
fun DashboardScreen(viewModel: PasswordViewModel) {
    val passwords by viewModel.passwords.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val context = LocalContext.current
    var passwordToDelete by remember { mutableStateOf<PasswordEntity?>(null) }

    Scaffold(
        containerColor = WebnetikBlack,
        modifier = Modifier
            .statusBarsPadding()
            .navigationBarsPadding(),
        floatingActionButton = {
            Button(
                onClick = { viewModel.navigateTo(Screen.AddPlatform) },
                colors = ButtonDefaults.buttonColors(containerColor = WebnetikRed),
                shape = RoundedCornerShape(24.dp), // Oval corner button
                modifier = Modifier
                    .height(56.dp)
                    .width(130.dp)
                    .testTag("add_platform_fab"),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Ekle", tint = WebnetikWhite)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Ekle",
                        color = WebnetikWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(WebnetikRed),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = "Key Icon",
                            tint = WebnetikWhite,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "WEBNETIK",
                            color = WebnetikWhite,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            letterSpacing = 1.5.sp
                        )
                        Text(
                            text = "Şifre Yöneticisi",
                            color = WebnetikGrayText,
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp
                        )
                    }
                }

                IconButton(
                    onClick = { viewModel.navigateTo(Screen.Settings) },
                    colors = IconButtonDefaults.iconButtonColors(
                        containerColor = WebnetikCardGrey
                    ),
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Ayarlar",
                        tint = WebnetikWhite,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Modern Rounded Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text("Platform veya kullanıcı adı ara...", color = WebnetikGrayText) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Ara",
                        tint = WebnetikGrayText
                    )
                },
                singleLine = true,
                shape = RoundedCornerShape(24.dp), // Modern Oval search bar
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = WebnetikSurface,
                    unfocusedContainerColor = WebnetikSurface,
                    focusedBorderColor = WebnetikRed,
                    unfocusedBorderColor = WebnetikBorder,
                    focusedTextColor = WebnetikWhite,
                    unfocusedTextColor = WebnetikWhite
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_bar")
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Kayıtlı Şifrelerim (${passwords.size})",
                color = WebnetikWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            if (passwords.isEmpty()) {
                // Empty State View
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(WebnetikSurface),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Kilit",
                            tint = WebnetikGrayText,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (searchQuery.isEmpty()) "Henüz Şifre Kaydedilmedi" else "Eşleşen Şifre Bulunamadı",
                        color = WebnetikWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (searchQuery.isEmpty()) "Yeni bir platform şifresi kaydetmek için 'Ekle' butonunu kullanın." else "Aramayı temizleyerek tekrar deneyin.",
                        color = WebnetikGrayText,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 32.dp)
                    )
                }
            } else {
                // Passwords List
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(passwords, key = { it.id }) { item ->
                        PasswordCard(
                            item = item,
                            viewModel = viewModel,
                            onDelete = { passwordToDelete = item }
                        )
                    }
                }
            }
        }
    }

    // Modern Confirm Delete Dialog
    passwordToDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { passwordToDelete = null },
            shape = RoundedCornerShape(24.dp), // Modern oval corner
            containerColor = WebnetikSurface,
            title = {
                Text(
                    text = "Şifreyi Sil",
                    color = WebnetikWhite,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "${item.platformName} platformuna ait şifreyi silmek istediğinizden emin misiniz?",
                    color = WebnetikGrayText
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deletePassword(item)
                        passwordToDelete = null
                        Toast.makeText(context, "Şifre silindi", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WebnetikRed),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Sil", color = WebnetikWhite, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { passwordToDelete = null }) {
                    Text("İptal", color = WebnetikGrayText)
                }
            }
        )
    }
}

@Composable
fun PasswordCard(
    item: PasswordEntity,
    viewModel: PasswordViewModel,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var passwordVisible by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(20.dp), // Oval corner card
        colors = CardDefaults.cardColors(
            containerColor = WebnetikSurface
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, WebnetikBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("password_card_${item.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Platform Logo and Details
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Dynamic Platform Logo with Fallback
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(WebnetikCardGrey),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(viewModel.getLogoUrl(item.platformName))
                            .crossfade(true)
                            .build(),
                        contentDescription = "Platform Logo",
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(6.dp)),
                        error = painterResource(id = android.R.drawable.ic_menu_help), // We fallback below if load fails or isn't available
                        fallback = painterResource(id = android.R.drawable.ic_menu_help)
                    )
                    // Custom robust Overlay fallback badge if logo failed/loading
                    // Shows the capitalized first letter on a beautiful red background
                    var isSuccess by remember { mutableStateOf(false) }
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(viewModel.getLogoUrl(item.platformName))
                            .build(),
                        contentDescription = null,
                        onSuccess = { isSuccess = true },
                        onError = { isSuccess = false },
                        modifier = Modifier.size(0.dp) // Just to pre-test success/failure
                    )

                    if (!isSuccess) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(WebnetikRed),
                            contentAlignment = Alignment.Center
                        ) {
                            val initial = if (item.platformName.isNotEmpty()) {
                                item.platformName.take(1).uppercase()
                            } else {
                                "P"
                            }
                            Text(
                                text = initial,
                                color = WebnetikWhite,
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                // Text details
                Column {
                    Text(
                        text = item.platformName,
                        color = WebnetikWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    if (item.username.isNotEmpty()) {
                        Text(
                            text = item.username,
                            color = WebnetikGrayText,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                    Text(
                        text = if (passwordVisible) item.password else "••••••••••••",
                        color = if (passwordVisible) WebnetikRedLight else WebnetikGrayText,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            // Quick Actions
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Show/hide password
                IconButton(
                    onClick = { passwordVisible = !passwordVisible },
                    colors = IconButtonDefaults.iconButtonColors(contentColor = WebnetikGrayText)
                ) {
                    Icon(
                        imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                        contentDescription = "Şifreyi Göster",
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Copy password to clipboard
                IconButton(
                    onClick = {
                        clipboardManager.setText(AnnotatedString(item.password))
                        Toast.makeText(context, "${item.platformName} şifresi kopyalandı", Toast.LENGTH_SHORT).show()
                    },
                    colors = IconButtonDefaults.iconButtonColors(contentColor = WebnetikGrayText)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Kopyala",
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Delete password
                IconButton(
                    onClick = onDelete,
                    colors = IconButtonDefaults.iconButtonColors(contentColor = WebnetikRedLight.copy(alpha = 0.8f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Sil",
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AddPlatformScreen(viewModel: PasswordViewModel) {
    val context = LocalContext.current
    var platformName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    
    var passwordVisible by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = WebnetikBlack,
        modifier = Modifier
            .statusBarsPadding()
            .navigationBarsPadding(),
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(Screen.Dashboard) },
                    colors = IconButtonDefaults.iconButtonColors(contentColor = WebnetikWhite)
                ) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Geri")
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "Şifre Ekle",
                    color = WebnetikWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Live Preview Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = WebnetikSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, WebnetikBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Live logo preview
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(WebnetikCardGrey),
                        contentAlignment = Alignment.Center
                    ) {
                        if (platformName.trim().isEmpty()) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = "Anahtar",
                                tint = WebnetikGrayText,
                                modifier = Modifier.size(28.dp)
                            )
                        } else {
                            var isLogoLoaded by remember { mutableStateOf(false) }
                            
                            // Track loading success
                            AsyncImage(
                                model = ImageRequest.Builder(context)
                                    .data(viewModel.getLogoUrl(platformName))
                                    .build(),
                                contentDescription = null,
                                onSuccess = { isLogoLoaded = true },
                                onError = { isLogoLoaded = false },
                                modifier = Modifier.size(0.dp)
                            )

                            if (isLogoLoaded) {
                                AsyncImage(
                                    model = ImageRequest.Builder(context)
                                        .data(viewModel.getLogoUrl(platformName))
                                        .crossfade(true)
                                        .build(),
                                    contentDescription = "Logo Önizleme",
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                )
                            } else {
                                // Fallback first letter
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(WebnetikRed),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = platformName.trim().take(1).uppercase(),
                                        color = WebnetikWhite,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 24.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Text(
                            text = if (platformName.isBlank()) "Platform Adı Girin" else platformName,
                            color = WebnetikWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = if (username.isBlank()) "Kullanıcı adı girilmedi" else username,
                            color = WebnetikGrayText,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Platform Name Input
            OutlinedTextField(
                value = platformName,
                onValueChange = { platformName = it },
                label = { Text("Platform Adı (Örn: Instagram, Google)") },
                placeholder = { Text("Instagram") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = WebnetikRed,
                    unfocusedBorderColor = WebnetikBorder,
                    focusedLabelColor = WebnetikRed,
                    unfocusedLabelColor = WebnetikGrayText,
                    focusedTextColor = WebnetikWhite,
                    unfocusedTextColor = WebnetikWhite
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("add_platform_name")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Username Input
            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                label = { Text("Kullanıcı Adı / E-posta") },
                placeholder = { Text("user@example.com") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = WebnetikRed,
                    unfocusedBorderColor = WebnetikBorder,
                    focusedLabelColor = WebnetikRed,
                    unfocusedLabelColor = WebnetikGrayText,
                    focusedTextColor = WebnetikWhite,
                    unfocusedTextColor = WebnetikWhite
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("add_platform_username")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Password Input with generator button and toggle visibility
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Şifre") },
                    placeholder = { Text("••••••••••••") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "Şifreyi Göster",
                                tint = WebnetikGrayText
                            )
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = WebnetikRed,
                        unfocusedBorderColor = WebnetikBorder,
                        focusedLabelColor = WebnetikRed,
                        unfocusedLabelColor = WebnetikGrayText,
                        focusedTextColor = WebnetikWhite,
                        unfocusedTextColor = WebnetikWhite
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_platform_password")
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Modern quick generate password button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = {
                            password = viewModel.generateSecurePassword()
                            passwordVisible = true
                            Toast.makeText(context, "Güçlü şifre üretildi", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = WebnetikRedLight)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = "Anahtar",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Güçlü Şifre Üret", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Round Done Button ("Tamam")
            Button(
                onClick = {
                    if (platformName.trim().isEmpty() || password.isEmpty()) {
                        Toast.makeText(context, "Lütfen platform adı ve şifre alanlarını doldurun", Toast.LENGTH_SHORT).show()
                    } else {
                        viewModel.addPassword(platformName, username, password, notes)
                        Toast.makeText(context, "Şifre başarıyla kaydedildi", Toast.LENGTH_SHORT).show()
                        viewModel.navigateTo(Screen.Dashboard)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = WebnetikRed),
                shape = RoundedCornerShape(24.dp), // Oval corner button
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("add_platform_submit"),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
            ) {
                Text(
                    text = "Tamam",
                    color = WebnetikWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
fun SettingsScreen(viewModel: PasswordViewModel) {
    var showAboutDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = WebnetikBlack,
        modifier = Modifier
            .statusBarsPadding()
            .navigationBarsPadding(),
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(Screen.Dashboard) },
                    colors = IconButtonDefaults.iconButtonColors(contentColor = WebnetikWhite)
                ) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Geri")
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "Ayarlar",
                    color = WebnetikWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 24.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = WebnetikSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, WebnetikBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    WebnetikLogo()
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Webnetik Security",
                        color = WebnetikWhite,
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp
                    )
                    Text(
                        text = "Ultra Hızlı Şifre Yöneticisi",
                        color = WebnetikGrayText,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            Text(
                text = "Genel",
                color = WebnetikWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                modifier = Modifier.padding(top = 8.dp, start = 8.dp)
            )

            // About list item
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = WebnetikSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, WebnetikBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showAboutDialog = true }
                    .testTag("about_option")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Hakkında",
                            tint = WebnetikRed,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = "Hakkında",
                                color = WebnetikWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "Geliştirici ve sürüm bilgileri",
                                color = WebnetikGrayText,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                    Text(text = "V1.0", color = WebnetikGrayText, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                }
            }
        }
    }

    // Exact About Dialog showing specified info
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            shape = RoundedCornerShape(24.dp), // Modern rounded dialog
            containerColor = WebnetikSurface,
            title = {
                Text(
                    text = "Hakkında",
                    color = WebnetikWhite,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Geliştirici: Webnetik Security",
                        color = WebnetikWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Sürüm: V1.0",
                        color = WebnetikWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showAboutDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = WebnetikRed),
                    shape = RoundedCornerShape(16.dp), // Oval corner button
                    modifier = Modifier.testTag("about_dialog_close")
                ) {
                    Text("Tamam", color = WebnetikWhite, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun SetupLoginScreen(viewModel: PasswordViewModel) {
    val context = LocalContext.current
    var masterPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var confirmVisible by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = WebnetikBlack,
        modifier = Modifier
            .statusBarsPadding()
            .navigationBarsPadding()
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            WebnetikLogo()
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text(
                text = "Güvenlik Kurulumu",
                color = WebnetikWhite,
                fontWeight = FontWeight.Black,
                fontSize = 24.sp,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "Webnetik Pass korumasını aktif etmek için yeni bir Master Şifre belirleyin.",
                color = WebnetikGrayText,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Master Password Input
            OutlinedTextField(
                value = masterPassword,
                onValueChange = { masterPassword = it },
                label = { Text("Yeni Master Şifre") },
                placeholder = { Text("••••••••") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Göster",
                            tint = WebnetikGrayText
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = WebnetikRed,
                    unfocusedBorderColor = WebnetikBorder,
                    focusedLabelColor = WebnetikRed,
                    unfocusedLabelColor = WebnetikGrayText,
                    focusedTextColor = WebnetikWhite,
                    unfocusedTextColor = WebnetikWhite
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("setup_master_password")
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Confirm Password Input
            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                label = { Text("Şifreyi Onayla") },
                placeholder = { Text("••••••••") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                visualTransformation = if (confirmVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    IconButton(onClick = { confirmVisible = !confirmVisible }) {
                        Icon(
                            imageVector = if (confirmVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Göster",
                            tint = WebnetikGrayText
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = WebnetikRed,
                    unfocusedBorderColor = WebnetikBorder,
                    focusedLabelColor = WebnetikRed,
                    unfocusedLabelColor = WebnetikGrayText,
                    focusedTextColor = WebnetikWhite,
                    unfocusedTextColor = WebnetikWhite
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("setup_confirm_password")
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Custom Oval Submit Button
            Button(
                onClick = {
                    if (masterPassword.isEmpty()) {
                        Toast.makeText(context, "Şifre alanı boş bırakılamaz", Toast.LENGTH_SHORT).show()
                    } else if (masterPassword != confirmPassword) {
                        Toast.makeText(context, "Şifreler eşleşmiyor!", Toast.LENGTH_SHORT).show()
                    } else {
                        viewModel.saveMasterPassword(masterPassword)
                        Toast.makeText(context, "Master Şifre başarıyla kaydedildi!", Toast.LENGTH_SHORT).show()
                        viewModel.navigateTo(Screen.Dashboard)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = WebnetikRed),
                shape = RoundedCornerShape(24.dp), // Oval corner button
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("setup_submit"),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
            ) {
                Text(
                    text = "Tamam",
                    color = WebnetikWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
fun LoginScreen(viewModel: PasswordViewModel) {
    val context = LocalContext.current
    var passwordInput by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = WebnetikBlack,
        modifier = Modifier
            .statusBarsPadding()
            .navigationBarsPadding()
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            WebnetikLogo()
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text(
                text = "Giriş Güvenliği",
                color = WebnetikWhite,
                fontWeight = FontWeight.Black,
                fontSize = 24.sp,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "Devam etmek için Master Şifrenizi girin.",
                color = WebnetikGrayText,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Master Password Entry field
            OutlinedTextField(
                value = passwordInput,
                onValueChange = { passwordInput = it },
                label = { Text("Master Şifre") },
                placeholder = { Text("••••••••") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Göster",
                            tint = WebnetikGrayText
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = WebnetikRed,
                    unfocusedBorderColor = WebnetikBorder,
                    focusedLabelColor = WebnetikRed,
                    unfocusedLabelColor = WebnetikGrayText,
                    focusedTextColor = WebnetikWhite,
                    unfocusedTextColor = WebnetikWhite
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("login_master_password")
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Custom Oval "Giriş Yap" Button
            Button(
                onClick = {
                    if (viewModel.verifyMasterPassword(passwordInput)) {
                        Toast.makeText(context, "Giriş başarılı", Toast.LENGTH_SHORT).show()
                        viewModel.navigateTo(Screen.Dashboard)
                    } else {
                        Toast.makeText(context, "Hatalı Master Şifre! Lütfen tekrar deneyin.", Toast.LENGTH_SHORT).show()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = WebnetikRed),
                shape = RoundedCornerShape(24.dp), // Oval corner button
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("login_submit"),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
            ) {
                Text(
                    text = "Tamam",
                    color = WebnetikWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

