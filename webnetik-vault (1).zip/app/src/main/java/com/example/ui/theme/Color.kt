package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Webnetik Premium Corporate Palette (Black, White, Red)
val WebnetikBlack = Color(0xFF0F0F11)
val WebnetikDarkGrey = Color(0xFF1B1B1F)
val WebnetikCardGrey = Color(0xFF242429)
val WebnetikRed = Color(0xFFE53935)
val WebnetikRedLight = Color(0xFFFF5252)
val WebnetikWhite = Color(0xFFFFFFFF)
val WebnetikGrayText = Color(0xFF9E9EAE)
val WebnetikBorder = Color(0xFF2E2E35)
val WebnetikSurface = Color(0xFF16161A)
