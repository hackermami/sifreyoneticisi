package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = WebnetikRed,
    onPrimary = WebnetikWhite,
    primaryContainer = WebnetikRed,
    onPrimaryContainer = WebnetikWhite,
    secondary = WebnetikRedLight,
    onSecondary = WebnetikBlack,
    background = WebnetikBlack,
    onBackground = WebnetikWhite,
    surface = WebnetikSurface,
    onSurface = WebnetikWhite,
    surfaceVariant = WebnetikCardGrey,
    onSurfaceVariant = WebnetikWhite,
    outline = WebnetikBorder,
    error = WebnetikRedLight,
    onError = WebnetikWhite
)

private val LightColorScheme = lightColorScheme(
    primary = WebnetikRed,
    onPrimary = WebnetikWhite,
    primaryContainer = WebnetikRed,
    onPrimaryContainer = WebnetikWhite,
    secondary = WebnetikRed,
    onSecondary = WebnetikWhite,
    background = Color(0xFFFAFAFA),
    onBackground = WebnetikBlack,
    surface = WebnetikWhite,
    onSurface = WebnetikBlack,
    surfaceVariant = Color(0xFFF0F0F2),
    onSurfaceVariant = WebnetikBlack,
    outline = Color(0xFFE0E0E5),
    error = WebnetikRed,
    onError = WebnetikWhite
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to true for premium look
    content: @Composable () -> Unit
) {
    // We explicitly use our customized brand colors to preserve Webnetik Security identity
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
